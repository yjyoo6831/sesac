SELECT * FROM lmsdb.user;

desc user;
alter table user add joindate datetime;



select * from user where userid='2' and pw='2';